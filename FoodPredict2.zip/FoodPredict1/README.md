# Food Image Classifier (Rice / Roti / Curry)

This project builds a food image classifier and serves predictions using FastAPI.

## Features
- Dataset downloader (`dataset.py`)
- Dataset cleaner (`clean_dataset.py`)
  - removes corrupted files
  - removes unsupported formats
  - removes very small images
  - removes blurry images
  - removes exact and near-duplicate images
- Model training (`train_model.py`)
  - supports `efficientnetb0` (default)
  - supports `mobilenetv2`
- FastAPI prediction service (`app.py`)
  - validates uploaded image quality
  - rejects mostly white / blank images
  - rejects images containing readable text overlays
  - returns class (`rice`, `roti`, `curry`) + confidence
  - returns `need_better_image=true` when quality/confidence is low
  - supports prediction from uploaded file and public image URL

## Project Structure
- `dataset.py`
- `clean_dataset.py`
- `train_model.py`
- `app.py`
- `image_utils.py`
- `requirements.txt`
- `dataset/rice`, `dataset/roti`, `dataset/curry`

## Setup
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## 1) Download Dataset (Optional)
```powershell
python dataset.py
```

## 2) Clean Dataset
Dry-run first:
```powershell
python clean_dataset.py --dry-run
```

Then delete invalid/low-quality/duplicate images:
```powershell
python clean_dataset.py
```

## 3) Train Model
EfficientNetB0 (recommended):
```powershell
python train_model.py --backbone efficientnetb0 --epochs 10 --image-size 224 --batch-size 16
```

For better performance on hard variants (for example fried rice), include fine-tuning:
```powershell
python train_model.py --backbone efficientnetb0 --epochs 10 --fine-tune-epochs 4 --image-size 224 --batch-size 16
```

MobileNetV2:
```powershell
python train_model.py --backbone mobilenetv2 --epochs 10 --image-size 224 --batch-size 16
```

Artifacts saved to `model/`:
- `food_classifier.keras`
- `class_names.json`
- `model_metadata.json`

## 4) Run FastAPI
```powershell
uvicorn app:app --reload
```

## OCR Requirement (Text Rejection)
Text detection uses OCR via `rapidocr-onnxruntime`, installed through `requirements.txt`.

No separate system OCR binary is required.

## 5) Test API
Health check:
```powershell
curl http://127.0.0.1:8000/health
```

Predict:
```powershell
curl -X POST "http://127.0.0.1:8000/predict" -F "file=@test.jpg"
```

Predict from URL:
```powershell
curl -X POST "http://127.0.0.1:8000/predict-url" ^
  -H "Content-Type: application/json" ^
  -d "{\"image_url\":\"https://example.com/food.jpg\"}"
```

## API Response Example
```json
{
  "status": "ok",
  "prediction": "rice",
  "confidence": 0.92,
  "need_better_image": false,
  "reason": "Prediction successful",
  "image_width": 512,
  "image_height": 512,
  "blur_score": 33.2,
  "probabilities": {
    "curry": 0.03,
    "rice": 0.92,
    "roti": 0.05
  }
}
```

If image is mostly white, blurry, too small, contains text overlay, invalid, or low confidence:
- `status` will be `rejected` or `uncertain`
- `need_better_image` will be `true`
