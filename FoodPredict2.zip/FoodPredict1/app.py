from __future__ import annotations

import io
import json
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Callable
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

import numpy as np

# Reduce TensorFlow startup info noise in the console.
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "1")
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")

import tensorflow as tf
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from PIL import Image, UnidentifiedImageError

from image_utils import validate_image_quality


MODEL_DIR = Path("model")
MODEL_PATH = MODEL_DIR / "food_classifier.keras"
CLASSES_PATH = MODEL_DIR / "class_names.json"
METADATA_PATH = MODEL_DIR / "model_metadata.json"
# Only accept predictions when the model is highly confident.
CONFIDENCE_THRESHOLD = 0.50
# Reject predictions where top classes are too close (ambiguous image).
MIN_MARGIN_THRESHOLD = 0.15
IMAGE_SIZE = 224
MAX_UPLOAD_SIZE_BYTES = 10 * 1024 * 1024
WHITE_RATIO_THRESHOLD = 0.90
TEXT_COVERAGE_THRESHOLD = 0.20


model: tf.keras.Model | None = None
class_names: list[str] = []
preprocess_input_fn: Callable[[np.ndarray], np.ndarray] | None = None


class PredictionResponse(BaseModel):
    status: str
    prediction: str | None
    confidence: float | None
    need_better_image: bool
    reason: str
    image_width: int | None
    image_height: int | None
    blur_score: float | None
    probabilities: dict[str, float] | None


class PredictURLRequest(BaseModel):
    image_url: str = Field(..., description="Public image URL")


def load_artifacts() -> None:
    global model
    global class_names
    global preprocess_input_fn
    global IMAGE_SIZE

    if not MODEL_PATH.exists() or not CLASSES_PATH.exists():
        raise RuntimeError(
            "Model artifacts are missing. Train first with: python train_model.py"
        )

    model = tf.keras.models.load_model(MODEL_PATH)
    class_names = json.loads(CLASSES_PATH.read_text(encoding="utf-8"))

    backbone = "efficientnetb0"
    image_size = IMAGE_SIZE
    if METADATA_PATH.exists():
        metadata = json.loads(METADATA_PATH.read_text(encoding="utf-8"))
        backbone = str(metadata.get("backbone", "efficientnetb0")).lower()
        image_size = int(metadata.get("image_size", IMAGE_SIZE))

    if backbone == "mobilenetv2":
        preprocess_input_fn = tf.keras.applications.mobilenet_v2.preprocess_input
    else:
        preprocess_input_fn = tf.keras.applications.efficientnet.preprocess_input

    IMAGE_SIZE = image_size


@asynccontextmanager
async def lifespan(_: FastAPI):
    load_artifacts()
    yield


app = FastAPI(title="Food Classifier API", version="1.0.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/")
def index() -> FileResponse:
    return FileResponse("static/index.html")


def preprocess_image(image: Image.Image) -> np.ndarray:
    if preprocess_input_fn is None:
        raise RuntimeError("Preprocess function is not loaded")

    resized = image.resize((IMAGE_SIZE, IMAGE_SIZE), Image.Resampling.LANCZOS)
    arr = np.asarray(resized, dtype=np.float32)
    arr = preprocess_input_fn(arr)
    return np.expand_dims(arr, axis=0)


def build_probabilities(pred_vector: np.ndarray, labels: list[str]) -> dict[str, float]:
    return {label: float(pred_vector[idx]) for idx, label in enumerate(labels)}


def fetch_image_bytes_from_url(image_url: str) -> bytes:
    import requests as _requests
    parsed = urlparse(image_url)
    if parsed.scheme not in {"http", "https"}:
        raise HTTPException(status_code=400, detail="Only http/https image URLs are allowed")

    try:
        resp = _requests.get(
            image_url,
            timeout=10,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
                "Referer": image_url,
            },
            verify=False,
            stream=True,
        )
        resp.raise_for_status()

        content_type = resp.headers.get("Content-Type", "")
        if not content_type.lower().startswith("image/"):
            raise HTTPException(status_code=400, detail="URL does not point to an image")

        raw_bytes = b""
        for chunk in resp.iter_content(64 * 1024):
            raw_bytes += chunk
            if len(raw_bytes) > MAX_UPLOAD_SIZE_BYTES:
                raise HTTPException(status_code=400, detail="Image exceeds 10MB limit")

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not fetch image URL: {exc}")

    if not raw_bytes:
        raise HTTPException(status_code=400, detail="Downloaded image is empty")
    return raw_bytes


def decode_image(raw_bytes: bytes) -> Image.Image:
    try:
        opened = Image.open(io.BytesIO(raw_bytes))
        opened.load()
        return opened.convert("RGB")
    except (UnidentifiedImageError, OSError, ValueError):
        raise HTTPException(status_code=400, detail="Invalid image file")


def predict_from_image(image: Image.Image) -> PredictionResponse:
    if model is None:
        raise HTTPException(status_code=500, detail="Model not loaded")

    quality = validate_image_quality(
        image,
        min_size=128,
        blur_threshold=12.0,
        white_ratio_threshold=WHITE_RATIO_THRESHOLD,
        reject_text=True,
        text_coverage_threshold=TEXT_COVERAGE_THRESHOLD,
    )
    if not quality.ok:
        return PredictionResponse(
            status="rejected",
            prediction=None,
            confidence=None,
            need_better_image=True,
            reason=quality.reason,
            image_width=quality.width,
            image_height=quality.height,
            blur_score=quality.blur_score,
            probabilities=None,
        )

    batch = preprocess_image(image)
    probs = model.predict(batch, verbose=0)[0]
    pred_idx = int(np.argmax(probs))
    confidence = float(probs[pred_idx])
    label = class_names[pred_idx]
    probabilities = build_probabilities(probs, class_names)
    sorted_probs = np.sort(probs)[::-1]
    top2_margin = float(sorted_probs[0] - sorted_probs[1]) if len(sorted_probs) > 1 else 1.0

    if confidence < CONFIDENCE_THRESHOLD or top2_margin < MIN_MARGIN_THRESHOLD:
        return PredictionResponse(
            status="uncertain",
            prediction=None,
            confidence=confidence,
            need_better_image=True,
            reason="Low confidence. Please upload a clearer, closer food image",
            image_width=quality.width,
            image_height=quality.height,
            blur_score=quality.blur_score,
            probabilities=probabilities,
        )

    return PredictionResponse(
        status="ok",
        prediction=label,
        confidence=confidence,
        need_better_image=False,
        reason="Prediction successful",
        image_width=quality.width,
        image_height=quality.height,
        blur_score=quality.blur_score,
        probabilities=probabilities,
    )


@app.post("/predict", response_model=PredictionResponse)
async def predict(file: UploadFile = File(...)) -> PredictionResponse:
    raw_bytes = await file.read()
    if not raw_bytes:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")
    if len(raw_bytes) > MAX_UPLOAD_SIZE_BYTES:
        raise HTTPException(status_code=400, detail="Image exceeds 10MB limit")

    image = decode_image(raw_bytes)
    return predict_from_image(image)


@app.post("/predict-url", response_model=PredictionResponse)
async def predict_url(payload: PredictURLRequest) -> PredictionResponse:
    raw_bytes = fetch_image_bytes_from_url(payload.image_url.strip())
    image = decode_image(raw_bytes)
    return predict_from_image(image)


# ==================================================
# AUTO DATABASE FOOD CLASSIFICATION
# ==================================================

import time
import threading
import pymysql


# --------------------------------------------------
# DATABASE CONFIG
# --------------------------------------------------
DB_CONFIG = {
    "host": "162.246.21.38",
    "user": "factory",
    "password": "Hy7FxTr#17",
    "database": "foodneedy",
    "cursorclass": pymysql.cursors.DictCursor
}

# --------------------------------------------------
# IMAGE BASE URL
# --------------------------------------------------
BASE_IMAGE_URL = "https://akulcreations.com/api/"


# --------------------------------------------------
# CONFIDENCE LEVEL
# --------------------------------------------------
def get_confidence_level(confidence):
    if confidence <= 0.33:
        return "low"
    elif confidence <= 0.66:
        return "medium"
    else:
        return "high"


# --------------------------------------------------
# DATABASE CONNECTION
# --------------------------------------------------
def get_connection():
    return pymysql.connect(
        host=DB_CONFIG["host"],
        user=DB_CONFIG["user"],
        password=DB_CONFIG["password"],
        database=DB_CONFIG["database"],
        cursorclass=DB_CONFIG["cursorclass"]
    )


# --------------------------------------------------
# PROCESS DONATIONS
# --------------------------------------------------
def process_donations():
    while True:
        connection = None
        try:
            connection = get_connection()
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT * FROM donations
                    WHERE food_type IS NULL OR food_type = ''
                """)
                donations = cursor.fetchall()
                print(f"\nFound {len(donations)} pending records")

                for donation in donations:
                    donation_id = donation["id"]
                    image_path = donation.get("image")
                    if not image_path:
                        continue

                    image_url = BASE_IMAGE_URL + image_path
                    print(f"\nProcessing ID : {donation_id}")
                    print(f"Image URL     : {image_url}")

                    try:
                        raw_bytes = fetch_image_bytes_from_url(image_url)
                        image = decode_image(raw_bytes)
                        result = predict_from_image(image)
                        print("Prediction :", result)

                        if result.status in ("ok", "uncertain") and result.probabilities:
                            prediction = result.prediction or max(result.probabilities, key=result.probabilities.get)
                            confidence_score = float(result.confidence or max(result.probabilities.values()))
                            confidence_level = get_confidence_level(confidence_score)
                            cursor.execute(
                                """
                                UPDATE donations
                                SET food_type = %s, perishability_level = %s
                                WHERE id = %s
                                """,
                                (prediction, confidence_level, donation_id)
                            )
                            connection.commit()
                            print(f"UPDATED -> {result.prediction}, {confidence_level}")

                    except Exception as prediction_error:
                        print(f"Prediction Error : {prediction_error}")

        except Exception as db_error:
            print(f"Database Error : {db_error}")

        finally:
            if connection:
                connection.close()

        time.sleep(3)


# --------------------------------------------------
# START BACKGROUND THREAD
# --------------------------------------------------
threading.Thread(target=process_donations, daemon=True).start()
