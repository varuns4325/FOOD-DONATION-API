from __future__ import annotations

import argparse
from collections import defaultdict
from pathlib import Path

from PIL import Image, UnidentifiedImageError

from image_utils import (
    average_hash,
    hamming_distance,
    image_sha256,
    is_supported_image,
    validate_image_quality,
)


def remove_file(file_path: Path, dry_run: bool) -> None:
    if not dry_run:
        file_path.unlink(missing_ok=True)


def clean_dataset(
    dataset_dir: Path,
    min_size: int,
    blur_threshold: float,
    duplicate_threshold: int,
    dry_run: bool,
) -> dict[str, int]:
    stats: dict[str, int] = defaultdict(int)

    for class_dir in sorted(dataset_dir.iterdir()):
        if not class_dir.is_dir():
            continue

        print(f"\nCleaning class: {class_dir.name}")
        exact_hashes: set[str] = set()
        perceptual_hashes: list[str] = []

        for file_path in sorted(class_dir.iterdir()):
            if not file_path.is_file():
                continue

            stats["total"] += 1
            if not is_supported_image(file_path):
                stats["removed_invalid_extension"] += 1
                print(f"[REMOVE] Unsupported extension: {file_path.name}")
                remove_file(file_path, dry_run)
                continue

            try:
                with Image.open(file_path) as opened:
                    opened.load()
                    image = opened.convert("RGB")
            except (UnidentifiedImageError, OSError, ValueError):
                stats["removed_corrupted"] += 1
                print(f"[REMOVE] Corrupted image: {file_path.name}")
                remove_file(file_path, dry_run)
                continue

            quality = validate_image_quality(
                image=image,
                min_size=min_size,
                blur_threshold=blur_threshold,
            )
            if not quality.ok:
                stats["removed_low_quality"] += 1
                print(f"[REMOVE] {file_path.name}: {quality.reason}")
                remove_file(file_path, dry_run)
                continue

            try:
                sha = image_sha256(file_path)
            except OSError:
                stats["removed_corrupted"] += 1
                print(f"[REMOVE] Read failed: {file_path.name}")
                remove_file(file_path, dry_run)
                continue

            if sha in exact_hashes:
                stats["removed_exact_duplicate"] += 1
                print(f"[REMOVE] Exact duplicate: {file_path.name}")
                remove_file(file_path, dry_run)
                continue
            exact_hashes.add(sha)

            phash = average_hash(image)
            duplicate_found = any(
                hamming_distance(phash, existing) <= duplicate_threshold
                for existing in perceptual_hashes
            )
            if duplicate_found:
                stats["removed_near_duplicate"] += 1
                print(f"[REMOVE] Near duplicate: {file_path.name}")
                remove_file(file_path, dry_run)
                continue

            perceptual_hashes.append(phash)
            stats["kept"] += 1

    return dict(stats)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Clean dataset by removing invalid, low-quality, and duplicate images.",
    )
    parser.add_argument("--dataset-dir", type=Path, default=Path("dataset"))
    parser.add_argument("--min-size", type=int, default=128)
    parser.add_argument("--blur-threshold", type=float, default=12.0)
    parser.add_argument(
        "--duplicate-threshold",
        type=int,
        default=4,
        help="Max hamming distance for perceptual near-duplicates.",
    )
    parser.add_argument("--dry-run", action="store_true")

    args = parser.parse_args()

    if not args.dataset_dir.exists():
        raise FileNotFoundError(f"Dataset directory not found: {args.dataset_dir}")

    stats = clean_dataset(
        dataset_dir=args.dataset_dir,
        min_size=args.min_size,
        blur_threshold=args.blur_threshold,
        duplicate_threshold=args.duplicate_threshold,
        dry_run=args.dry_run,
    )

    print("\n===== CLEANUP SUMMARY =====")
    for key in sorted(stats):
        print(f"{key}: {stats[key]}")
    print(f"Mode: {'DRY-RUN' if args.dry_run else 'DELETE'}")


if __name__ == "__main__":
    main()
