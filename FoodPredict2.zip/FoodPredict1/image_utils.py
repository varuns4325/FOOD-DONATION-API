from __future__ import annotations

import hashlib
import io
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image, ImageFilter, ImageStat

try:
    from rapidocr_onnxruntime import RapidOCR
except Exception:  # pragma: no cover - optional dependency during static checks
    RapidOCR = None


_ocr_engine: Any | None = None


VALID_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


@dataclass
class ImageQualityResult:
    ok: bool
    reason: str
    width: int
    height: int
    blur_score: float
    white_ratio: float | None = None
    text_detected: bool = False
    text_coverage_ratio: float = 0.0


def decode_image_bytes(raw_bytes: bytes) -> Image.Image:
    image = Image.open(io.BytesIO(raw_bytes))
    image.load()
    return image.convert("RGB")


def calculate_blur_score(image: Image.Image) -> float:
    # Edge variance is a simple, fast proxy for sharpness.
    edges = image.convert("L").filter(ImageFilter.FIND_EDGES)
    variance = ImageStat.Stat(edges).var
    return float(variance[0]) if variance else 0.0


def calculate_white_ratio(image: Image.Image, near_white_rgb_threshold: int = 245) -> float:
    arr = np.asarray(image.convert("RGB"), dtype=np.uint8)
    white_mask = np.all(arr >= near_white_rgb_threshold, axis=2)
    return float(white_mask.mean())


def extract_text_metrics(image: Image.Image) -> tuple[int, float]:
    # Returns (alnum_chars_detected, text_area_ratio).
    global _ocr_engine
    if RapidOCR is None:
        return 0, 0.0

    try:
        if _ocr_engine is None:
            _ocr_engine = RapidOCR()
        result, _ = _ocr_engine(np.asarray(image.convert("RGB"), dtype=np.uint8))
    except Exception:
        return 0, 0.0

    if not result:
        return 0, 0.0

    extracted: list[str] = []
    text_area = 0.0
    img_area = float(max(image.size[0] * image.size[1], 1))

    def polygon_area(points: list[list[float]]) -> float:
        if len(points) < 3:
            return 0.0
        area = 0.0
        for idx in range(len(points)):
            x1, y1 = points[idx]
            x2, y2 = points[(idx + 1) % len(points)]
            area += (x1 * y2) - (x2 * y1)
        return abs(area) * 0.5

    for item in result:
        if len(item) > 1 and isinstance(item[1], str):
            extracted.append(item[1])
        if len(item) > 0 and isinstance(item[0], list):
            points = [p for p in item[0] if isinstance(p, list) and len(p) == 2]
            text_area += polygon_area(points)

    text = " ".join(extracted)

    if not text.strip():
        return 0, 0.0

    alnum_count = len(re.findall(r"[A-Za-z0-9]", text))
    text_coverage_ratio = float(min(text_area / img_area, 1.0))
    return alnum_count, text_coverage_ratio


def validate_image_quality(
    image: Image.Image,
    min_size: int = 128,
    blur_threshold: float = 12.0,
    white_ratio_threshold: float = 0.90,
    near_white_rgb_threshold: int = 245,
    reject_text: bool = True,
    text_coverage_threshold: float = 0.20,
) -> ImageQualityResult:
    width, height = image.size
    if width < min_size or height < min_size:
        return ImageQualityResult(
            ok=False,
            reason=f"Image too small. Minimum size is {min_size}x{min_size}",
            width=width,
            height=height,
            blur_score=0.0,
            white_ratio=None,
            text_detected=False,
            text_coverage_ratio=0.0,
        )

    white_ratio = calculate_white_ratio(
        image,
        near_white_rgb_threshold=near_white_rgb_threshold,
    )
    if white_ratio > white_ratio_threshold:
        return ImageQualityResult(
            ok=False,
            reason="Image is mostly white/blank. Please upload a proper food image",
            width=width,
            height=height,
            blur_score=0.0,
            white_ratio=white_ratio,
            text_detected=False,
            text_coverage_ratio=0.0,
        )

    blur_score = calculate_blur_score(image)
    if blur_score < blur_threshold:
        return ImageQualityResult(
            ok=False,
            reason="Image is too blurry. Please upload a clearer image",
            width=width,
            height=height,
            blur_score=blur_score,
            white_ratio=white_ratio,
            text_detected=False,
            text_coverage_ratio=0.0,
        )

    text_detected = False
    text_coverage_ratio = 0.0
    if reject_text:
        alnum_count, text_coverage_ratio = extract_text_metrics(image)
        text_detected = alnum_count >= 3 and text_coverage_ratio >= text_coverage_threshold

    if text_detected:
        return ImageQualityResult(
            ok=False,
            reason=f"Image contains heavy text overlay (>= {int(text_coverage_threshold * 100)}%). Please upload a clean food photo",
            width=width,
            height=height,
            blur_score=blur_score,
            white_ratio=white_ratio,
            text_detected=True,
            text_coverage_ratio=text_coverage_ratio,
        )

    return ImageQualityResult(
        ok=True,
        reason="ok",
        width=width,
        height=height,
        blur_score=blur_score,
        white_ratio=white_ratio,
        text_detected=False,
        text_coverage_ratio=text_coverage_ratio,
    )


def image_sha256(file_path: Path) -> str:
    digest = hashlib.sha256()
    with file_path.open("rb") as file:
        while True:
            chunk = file.read(8192)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def average_hash(image: Image.Image, hash_size: int = 8) -> str:
    # Average hash helps detect near-duplicate images quickly.
    tiny = image.convert("L").resize((hash_size, hash_size), Image.Resampling.LANCZOS)
    arr = np.asarray(tiny, dtype=np.float32)
    avg = arr.mean()
    bits = (arr >= avg).astype(np.uint8).flatten()
    return "".join(str(int(bit)) for bit in bits)


def hamming_distance(hash_a: str, hash_b: str) -> int:
    return sum(c1 != c2 for c1, c2 in zip(hash_a, hash_b))


def is_supported_image(file_path: Path) -> bool:
    return file_path.suffix.lower() in VALID_SUFFIXES
