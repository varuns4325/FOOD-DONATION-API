from __future__ import annotations

import argparse
import json
import ssl
from pathlib import Path
from typing import Callable

ssl._create_default_https_context = ssl._create_unverified_context

import tensorflow as tf
from tensorflow import keras


def get_backbone(
    backbone: str,
    image_size: int,
) -> tuple[keras.Model, Callable[[tf.Tensor], tf.Tensor]]:
    if backbone == "efficientnetb0":
        base_model = keras.applications.EfficientNetB0(
            input_shape=(image_size, image_size, 3),
            include_top=False,
            weights="imagenet",
        )
        preprocess = keras.applications.efficientnet.preprocess_input
        return base_model, preprocess

    if backbone == "mobilenetv2":
        base_model = keras.applications.MobileNetV2(
            input_shape=(image_size, image_size, 3),
            include_top=False,
            weights="imagenet",
        )
        preprocess = keras.applications.mobilenet_v2.preprocess_input
        return base_model, preprocess

    raise ValueError(f"Unsupported backbone: {backbone}")


def build_model(
    image_size: int,
    num_classes: int,
    backbone: str,
) -> tuple[keras.Model, keras.Model]:
    data_augmentation = keras.Sequential(
        [
            keras.layers.RandomFlip("horizontal"),
            keras.layers.RandomRotation(0.08),
            keras.layers.RandomZoom(0.1),
        ]
    )

    base_model, preprocess_input = get_backbone(backbone=backbone, image_size=image_size)
    base_model.trainable = False

    inputs = keras.Input(shape=(image_size, image_size, 3))
    x = data_augmentation(inputs)
    x = preprocess_input(x)
    x = base_model(x, training=False)
    x = keras.layers.GlobalAveragePooling2D()(x)
    x = keras.layers.Dropout(0.2)(x)
    outputs = keras.layers.Dense(num_classes, activation="softmax")(x)

    model = keras.Model(inputs, outputs)
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model, base_model


def train(
    dataset_dir: Path,
    output_dir: Path,
    image_size: int,
    batch_size: int,
    epochs: int,
    backbone: str,
    fine_tune_epochs: int,
) -> None:
    if not dataset_dir.exists():
        raise FileNotFoundError(f"Dataset directory not found: {dataset_dir}")

    train_ds = keras.utils.image_dataset_from_directory(
        dataset_dir,
        validation_split=0.2,
        subset="training",
        seed=42,
        image_size=(image_size, image_size),
        batch_size=batch_size,
    )
    val_ds = keras.utils.image_dataset_from_directory(
        dataset_dir,
        validation_split=0.2,
        subset="validation",
        seed=42,
        image_size=(image_size, image_size),
        batch_size=batch_size,
    )

    class_names = train_ds.class_names
    print(f"Class names: {class_names}")

    autotune = tf.data.AUTOTUNE
    train_ds = train_ds.cache().shuffle(1000).prefetch(buffer_size=autotune)
    val_ds = val_ds.cache().prefetch(buffer_size=autotune)

    model, base_model = build_model(
        image_size=image_size,
        num_classes=len(class_names),
        backbone=backbone,
    )

    callbacks = [
        keras.callbacks.EarlyStopping(
            monitor="val_accuracy",
            patience=3,
            restore_best_weights=True,
        )
    ]

    model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=epochs,
        callbacks=callbacks,
        verbose=1,
    )

    if fine_tune_epochs > 0:
        # Fine-tuning helps the model adapt to dataset-specific variants like fried rice.
        base_model.trainable = True
        freeze_until = int(len(base_model.layers) * 0.7)
        for layer in base_model.layers[:freeze_until]:
            layer.trainable = False

        model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=1e-5),
            loss="sparse_categorical_crossentropy",
            metrics=["accuracy"],
        )

        model.fit(
            train_ds,
            validation_data=val_ds,
            epochs=epochs + fine_tune_epochs,
            initial_epoch=epochs,
            callbacks=callbacks,
            verbose=1,
        )

    val_loss, val_accuracy = model.evaluate(val_ds, verbose=0)
    print(f"Validation accuracy: {val_accuracy:.4f}, loss: {val_loss:.4f}")

    output_dir.mkdir(parents=True, exist_ok=True)
    model_path = output_dir / "food_classifier.keras"
    classes_path = output_dir / "class_names.json"
    metadata_path = output_dir / "model_metadata.json"

    model.save(model_path)
    classes_path.write_text(json.dumps(class_names, indent=2), encoding="utf-8")
    metadata_path.write_text(
        json.dumps(
            {
                "backbone": backbone,
                "image_size": image_size,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print(f"Model saved at: {model_path}")
    print(f"Class names saved at: {classes_path}")
    print(f"Metadata saved at: {metadata_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Train food image classifier model.")
    parser.add_argument("--dataset-dir", type=Path, default=Path("dataset"))
    parser.add_argument("--output-dir", type=Path, default=Path("model"))
    parser.add_argument("--image-size", type=int, default=224)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--fine-tune-epochs", type=int, default=4)
    parser.add_argument(
        "--backbone",
        type=str,
        default="efficientnetb0",
        choices=["efficientnetb0", "mobilenetv2"],
    )
    args = parser.parse_args()

    train(
        dataset_dir=args.dataset_dir,
        output_dir=args.output_dir,
        image_size=args.image_size,
        batch_size=args.batch_size,
        epochs=args.epochs,
        backbone=args.backbone,
        fine_tune_epochs=args.fine_tune_epochs,
    )


if __name__ == "__main__":
    main()
