
Food Donation API

Run:
uvicorn main:app --reload

Endpoint:
POST /allocate
