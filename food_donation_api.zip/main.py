
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class AllocationRequest(BaseModel):
    request_id: str
    location: str
    required_quantity: int

# Dummy database
donations = [
    {"donation_id": "DON1", "location": "Bangalore", "quantity": 100},
    {"donation_id": "DON2", "location": "Bangalore", "quantity": 50},
]

@app.post("/allocate")
def allocate_food(request: AllocationRequest):
    for donation in donations:
        if donation["location"] == request.location and donation["quantity"] >= request.required_quantity:
            donation["quantity"] -= request.required_quantity
            return {
                "status": "allocated",
                "donation_id": donation["donation_id"],
                "allocated_quantity": request.required_quantity,
                "message": "Food successfully allocated"
            }

    return {
        "status": "failed",
        "message": "Not enough food available"
    }
